package mago.apps.orot_medication.model

enum class State {
    IDLE,
    CONNECTED,
    CLOSED,
    ERROR
}