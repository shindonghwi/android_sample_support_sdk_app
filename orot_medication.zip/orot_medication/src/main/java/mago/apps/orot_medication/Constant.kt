package mago.apps.orot_medication

val TAG: String = "OrotMedicationSDK"
val MSG_SOCKET_CLOSED = "Socket Closed"
val MSG_SOCKET_CONNECTION_ERROR = "Socket Connection Error"
val MSG_SOCKET_CLOSE_ERROR = "$TAG close Error"